package com.ccko.pikxplus.ui.matrix;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;

public class ImageMatrixController {
    private ImageView imageView;
    private Matrix imageMatrix = new Matrix();
    private float scaleFactor = 1.0f;
    private float fitScale = 1.0f;
    
    public ImageMatrixController(ImageView imageView) {
        this.imageView = imageView;
        this.imageView.setScaleType(ImageView.ScaleType.MATRIX);
    }
    
    // SAFE TO MOVE: Pure calculation, no fragment dependencies
    public Matrix computeInitialMatrix(ImageView imgView) {
        Drawable drawable = imgView.getDrawable();
        if (drawable == null) {
            return new Matrix();
        }

        int drawWidth = drawable.getIntrinsicWidth();
        int drawHeight = drawable.getIntrinsicHeight();
        int viewWidth = imgView.getWidth();
        int viewHeight = imgView.getHeight();

        if (drawWidth <= 0 || drawHeight <= 0 || viewWidth <= 0 || viewHeight <= 0) {
            return new Matrix();
        }

        float scale = Math.min((float) viewWidth / drawWidth, (float) viewHeight / drawHeight);
        Matrix matrix = new Matrix();
        matrix.setScale(scale, scale);

        float dx = (viewWidth - drawWidth * scale) / 2f;
        float dy = (viewHeight - drawHeight * scale) / 2f;
        matrix.postTranslate(dx, dy);
        fitScale = scale; // Store the base fit scale
        return matrix;
    }
    
    // SAFE TO MOVE: Pure matrix calculation
    public RectF getDisplayRect(Matrix matrix) {
        Drawable d = imageView.getDrawable();
        if (d == null) return null;

        RectF rect = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        matrix.mapRect(rect);
        return rect;
    }
    
    // SAFE TO MOVE: Pure clamping logic
    public void clampMatrixForMatrix(Matrix m) {
        RectF r = getDisplayRect(m);
        if (r == null) return;

        int viewW = imageView.getWidth();
        int viewH = imageView.getHeight();
        if (viewW == 0 || viewH == 0) return;

        float deltaX = 0f;
        float deltaY = 0f;

        // Horizontal clamp / center
        if (r.width() <= viewW) {
            // center horizontally
            deltaX = (viewW - r.width()) * 0.5f - r.left;
        } else {
            if (r.left > 0) {
                deltaX = -r.left;
            } else if (r.right < viewW) {
                deltaX = viewW - r.right;
            }
        }

        // Vertical clamp / center
        if (r.height() <= viewH) {
            // center vertically
            deltaY = (viewH - r.height()) * 0.5f - r.top;
        } else {
            if (r.top > 0) {
                deltaY = -r.top;
            } else if (r.bottom < viewH) {
                deltaY = viewH - r.bottom;
            }
        }

        if (Math.abs(deltaX) > 0.5f || Math.abs(deltaY) > 0.5f) {
            m.postTranslate(deltaX, deltaY);
        }
    }
    
    // SAFE TO MOVE: Self-contained, only needs ImageView
    public void clampMatrix() {
        Drawable drawable = imageView.getDrawable();
        if (drawable == null) return;

        float[] values = new float[9];
        imageMatrix.getValues(values);
        float scaleX = values[Matrix.MSCALE_X];
        float transX = values[Matrix.MTRANS_X];
        float transY = values[Matrix.MTRANS_Y];

        int drawWidth = drawable.getIntrinsicWidth();
        int drawHeight = drawable.getIntrinsicHeight();
        int viewWidth = imageView.getWidth();
        int viewHeight = imageView.getHeight();

        // Scaled dimensions
        float scaledWidth = drawWidth * scaleX;
        float scaledHeight = drawHeight * scaleX; // Assume uniform scale

        // Clamp X: Don't pan left if left edge is visible, etc.
        if (scaledWidth > viewWidth) {
            // Can pan horizontally
            float minTransX = viewWidth - scaledWidth;
            float maxTransX = 0f;
            transX = Math.max(minTransX, Math.min(transX, maxTransX));
        } else { // Center if smaller
            transX = (viewWidth - scaledWidth) / 2f;
        }

        // Clamp Y (same logic)
        if (scaledHeight > viewHeight) {
            float minTransY = viewHeight - scaledHeight;
            float maxTransY = 0f;
            transY = Math.max(minTransY, Math.min(transY, maxTransY));
        } else {
            transY = (viewHeight - scaledHeight) / 2f;
        }

        // Apply clamped values
        values[Matrix.MTRANS_X] = transX;
        values[Matrix.MTRANS_Y] = transY;
        imageMatrix.setValues(values);
        imageView.setImageMatrix(imageMatrix);
    }
    
    // Basic setters/getters to replace fragment fields
    public void setMatrix(Matrix matrix) {
        imageMatrix.set(matrix);
        imageView.setImageMatrix(imageMatrix);
    }
    
    public Matrix getMatrix() {
        return new Matrix(imageMatrix);
    }
    
    public void setScaleFactor(float scale) {
        scaleFactor = scale;
    }
    
    public float getScaleFactor() {
        return scaleFactor;
    }
    
    public float getFitScale() {
        return fitScale;
    }
}