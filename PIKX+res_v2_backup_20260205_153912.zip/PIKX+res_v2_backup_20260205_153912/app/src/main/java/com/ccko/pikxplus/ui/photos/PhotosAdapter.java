package com.ccko.pikxplus.ui.photos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ccko.pikxplus.R;
import com.ccko.pikxplus.adapters.MediaItems;

import java.util.ArrayList;
import java.util.List;

public class PhotosAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

  private static final int TYPE_HEADER = 0;
  private static final int TYPE_MEDIA = 1;
  private static final int TYPE_PLACEHOLDER = 2;

  private final List<MediaItems> mediaList = new ArrayList<>();
  private boolean isGridView = true;
  private boolean isLoading = true;

  private static final int PLACEHOLDER_COUNT = 12;

  public interface Callback {
    void onMediaClicked(int index);

    void onSortClicked(View anchor);

    void onViewModeClicked(View anchor);
  }

  private final Callback callback;
  private String albumName;

  public PhotosAdapter(Callback callback) {
    this.callback = callback;
  }

  // ---------- public API ----------

  public void setAlbumName(String name) {
    this.albumName = name;
    notifyItemChanged(0);
  }

  public void setViewMode(boolean grid) {
    isGridView = grid;
    notifyDataSetChanged();
  }

  public void showLoading() {
    isLoading = true;
    mediaList.clear();
    notifyDataSetChanged();
  }

  public void submitMedia(List<MediaItems> items) {
    isLoading = false;
    mediaList.clear();
    mediaList.addAll(items);
    notifyDataSetChanged();
  }

  // ---------- adapter core ----------

  @Override
  public int getItemCount() {
    if (isLoading) {
      return 1 + PLACEHOLDER_COUNT; // header + placeholders
    }
    return mediaList.isEmpty() ? 1 : mediaList.size() + 1;
  }

  @Override
  public int getItemViewType(int position) {
    if (position == 0) return TYPE_HEADER;
    if (isLoading) return TYPE_PLACEHOLDER;
    return TYPE_MEDIA;
  }

  @NonNull
  @Override
  public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    LayoutInflater inflater = LayoutInflater.from(parent.getContext());

    if (viewType == TYPE_HEADER) {
      return new HeaderVH(inflater.inflate(R.layout.item_photo_header, parent, false));
    }

    if (viewType == TYPE_PLACEHOLDER) {
      int layout = isGridView ? R.layout.item_photo_grid : R.layout.item_photo_list;
      return new PlaceholderVH(inflater.inflate(layout, parent, false));
    }

    int layout = isGridView ? R.layout.item_photo_grid : R.layout.item_photo_list;

    return new MediaVH(inflater.inflate(layout, parent, false));
  }

  @Override
  public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
    if (holder instanceof HeaderVH) {
      ((HeaderVH) holder).bind();
      return;
    }

    if (holder instanceof PlaceholderVH) {
      ((PlaceholderVH) holder).bind();
      return;
    }

    int mediaIndex = position - 1;
    ((MediaVH) holder).bind(mediaList.get(mediaIndex), mediaIndex);
  }

  // ---------- view holders ----------

  class HeaderVH extends RecyclerView.ViewHolder {
    ImageView image;
    TextView title;
    ImageButton sort;
    ImageButton viewMode;

    HeaderVH(View v) {
      super(v);
      image = v.findViewById(R.id.headerImage);
      title = v.findViewById(R.id.albumTitle);
      sort = v.findViewById(R.id.sortButton);
      viewMode = v.findViewById(R.id.viewModeButton);

      sort.setOnClickListener(b -> callback.onSortClicked(sort));
      viewMode.setOnClickListener(b -> callback.onViewModeClicked(viewMode));
    }

    void bind() {
      title.setText(albumName != null ? albumName : "");

      image.setImageResource(R.drawable.ic_broken_image);
    }
  }

  class PlaceholderVH extends RecyclerView.ViewHolder {
    ImageView thumb;

    PlaceholderVH(View v) {
      super(v);
      thumb = v.findViewById(R.id.photoThumbnail);
    }

    void bind() {
      thumb.setImageResource(R.drawable.ic_broken_image);
    }
  }

  class MediaVH extends RecyclerView.ViewHolder {
    ImageView thumb;
    TextView title;
    TextView details;
    View container;

    MediaVH(View v) {
      super(v);
      thumb = v.findViewById(R.id.photoThumbnail);
      title = v.findViewById(R.id.photoTitle);
      details = v.findViewById(R.id.photoDetails);
      container = v.findViewById(R.id.photoContainer);
    }

    void bind(MediaItems item, int index) {
      container.setOnClickListener(v -> callback.onMediaClicked(index));

      if (isGridView) {
        if (title != null) title.setVisibility(View.GONE);
        if (details != null) details.setVisibility(View.GONE);
      } else {
        if (title != null) {
          title.setVisibility(View.VISIBLE);
          title.setText(item.name);
        }
        if (details != null) {
          details.setVisibility(View.VISIBLE);
          details.setText(
              item.isVideo()
                  ? item.getFormattedDuration() + " • " + formatSize(item.size)
                  : item.getFormattedDimensions() + " • " + formatSize(item.size));
        }
      }

      Glide.with(itemView.getContext()).load(item.uri).centerCrop().into(thumb);
    }
  }

  // ---------- helpers ----------

  private String formatSize(long size) {
    float mb = size / (1024f * 1024f);
    return String.format("%.1f MB", mb);
  }
}
